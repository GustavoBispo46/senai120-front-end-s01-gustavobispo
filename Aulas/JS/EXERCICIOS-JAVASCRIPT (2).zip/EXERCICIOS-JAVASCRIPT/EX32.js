let num1 = 1;
let num2 = 2;

if (num1 === num2) {
  console.log("Os números são iguais");
} else {
  console.log("Os números são diferentes");
}