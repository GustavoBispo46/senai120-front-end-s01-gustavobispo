let numero = 0;

while (numero <=20) {
    if(numero %2  ==0)
    console.log(numero);
    numero ++
}