let numeros = [];
let i = 1;

while (i <= 10) {
    numeros.push(i)
    i++
}
console.log(numeros);