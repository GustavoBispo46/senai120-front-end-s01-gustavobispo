let idade = 15
if(idade >= 18){
    console.log("Você é maior de idade");
}
else if (idade <18)
    console.log("Você é menor de idade");

