let n1= Number(prompt("Digite o número que será multiplicado por 3"))
let triplo = 3;
alert (n1*3)

