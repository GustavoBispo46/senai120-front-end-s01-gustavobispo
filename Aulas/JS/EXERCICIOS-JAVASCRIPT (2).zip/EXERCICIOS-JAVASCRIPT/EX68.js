let textoNome = document.querySelector("#texto")
let quantidadeNomes  = Number(prompt("Digite a quantidade de nomes que deseja adicionar"));
let nomes =[];
let i = 0;
while(nomes.length ==quantidadeNomes){
    i++
}
let nome = prompt("Escreva os nomes")
if(quantidadeNomes *5){
    i++
}