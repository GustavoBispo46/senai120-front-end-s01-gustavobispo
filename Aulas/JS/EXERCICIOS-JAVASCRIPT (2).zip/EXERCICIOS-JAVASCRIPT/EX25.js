let idade = 15
if (idade <=16){
    console.log("Você não pode votar");
}
else if (n>16){
    console.log("você pode votar");
}