let numero1 = 0;

while (numero1<=10){
    let numero1 = 
    numero1++
}
console.log(soma);