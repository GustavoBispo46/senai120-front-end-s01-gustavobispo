let numeros = [10,15,20]
let soma = 0;
let i = 0;
while (i<numeros.length){
    soma += numeros[i];
    i++;
}
console.log(soma);