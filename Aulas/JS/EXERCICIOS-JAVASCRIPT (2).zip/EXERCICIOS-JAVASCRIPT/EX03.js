
let n1 = 12
let n2 = 10
let n3 = 20
let d = 2
let div = (n1+n2+n3)/d
console.log(div);