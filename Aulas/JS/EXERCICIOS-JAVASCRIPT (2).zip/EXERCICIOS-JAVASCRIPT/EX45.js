let posicao = 2
let mensagem;

switch (posicao){   
    case 1:  
        mensagem = "Inglaterra ficou em 1 na UEFA 2021" 
        break;
    case 2:
        mensagem = "Espanha ficou em 2 lugar na UEFA 2021"
        break;    
    case 3:
        mensagem = "Alemanha ficou em 3 lugar na UEFA 2021"
        break;    
}
console.log(posicao);
console.log(mensagem);