let nota1 = 4;
let nota2 = 5;
let nota3 = 6;
let divisor = 10;
let media = nota1+nota2+nota3/divisor
console.log(media);
