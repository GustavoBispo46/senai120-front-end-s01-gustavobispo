let numero1 = 0;
let soma =0;
while (numero1<=100){
    soma += numero1
    numero1++
}
console.log(soma);

