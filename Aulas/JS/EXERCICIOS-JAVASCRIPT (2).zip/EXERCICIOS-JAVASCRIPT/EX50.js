let filme = 3;
let mensagem;

switch(filme){
    case 1:
        mensagem = "Velozes e Furiosos - 13 Anos"
        break;
    case 2:
        mensagem = " Gente Grande 1 - 12 Anos"
        break;

    case 3:
        mensagem = "Carros - 13 Anos"
        break;

    case 4:
        mensagem = "Creed - 12 Anos"
        break;

    case 5:
        mensagem = "Angry Birds - livre"
        break;
 }
 console.log(filme);
 console.log(mensagem);