let nomes = ["Gustavo","Fabio","Bruno"];
let i = 0;
let stringNomes = "";

while (i <nomes.length) {
    stringNomes += nomes[1] + " ";
    i++
}
console.log(stringNomes);