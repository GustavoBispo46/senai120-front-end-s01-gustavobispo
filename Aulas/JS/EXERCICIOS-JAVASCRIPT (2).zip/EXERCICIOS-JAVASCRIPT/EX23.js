let n1 = 7;
let n2 = 8;
let n3 = 1;

if(n1>n2 && n1>n3){
    console.log(+n1+" é o maior");
}
else if (n2>n1 && n2>n3){
    console.log(+n2+" é o maior");
}
else{
    console.log(+n3+" é o maior");
}