let basemaior = 40;
let basemenor = 20;
let altura = 10;

let areatrap = basemaior + basemenor * altura / 2;
console.log(areatrap);