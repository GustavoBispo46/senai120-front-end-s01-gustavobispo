let array = [10,15,20];
let soma = 0;

for(let i =0; i<array.length; i++){
    soma += array[i];
}
console.log("A soma dos números do array é:"+ soma);