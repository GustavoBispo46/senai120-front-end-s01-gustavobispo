let b = 4
let h = 2
let divisor = 2
let div = b*h /2
console.log(div);