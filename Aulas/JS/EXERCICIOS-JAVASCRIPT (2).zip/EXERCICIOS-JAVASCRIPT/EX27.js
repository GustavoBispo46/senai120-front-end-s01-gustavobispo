let nome = "Gustavo"
if(nome == "maria"){
    console.log("O seu nome é igual");
}
else{
    console.log("O seu nome não é igual o de maria");
}
