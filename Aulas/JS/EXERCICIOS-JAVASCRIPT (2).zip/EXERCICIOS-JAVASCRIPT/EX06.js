let b = 8;
let h = 5;
let mult = b*h
console.log(mult);