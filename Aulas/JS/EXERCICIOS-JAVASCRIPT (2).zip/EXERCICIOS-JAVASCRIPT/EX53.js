let numero1 = 3;

while(numero1 <=30){
    if(numero1 % 3 ==0)
    
        console.log(numero1);
    
    numero1 ++
 }