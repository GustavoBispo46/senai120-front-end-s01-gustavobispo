let array1 = [5,6,7];
let array2 = [8,9,10];
let novoArray = [];

for (let i = 0; i<array1.length; i++){
    novoArray.push(array1[i]);
}
for (let i =0; i<array2.length; i++){
    novoArray.push(array2[i]);
}
console.log(novoArray);
