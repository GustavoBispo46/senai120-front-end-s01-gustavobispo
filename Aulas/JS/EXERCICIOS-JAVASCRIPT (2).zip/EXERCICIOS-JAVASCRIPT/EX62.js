let numeros = [];
let i = 0;

while (i <= 20) {
    if (i%2 ==0){
        numeros.push(i)
        console.log(i);
    }
    
    i++
}
console.log(numeros);