let numero = 1;
let produto = 1;

while (numero <=5){
    produto *= numero
    numero++
}

console.log(produto);