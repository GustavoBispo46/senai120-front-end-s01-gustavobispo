let animal = 3;
let mensagem;

switch(animal){
    case 1:
        mensagem = "Leão - feroz e imperialista"
        break;
    case 2:
        mensagem = " Cachorro - companheiro e amigavel "
        break;

    case 3:
        mensagem = "Gato - curioso e amigável "
        break;

    case 4:
        mensagem = "Girafa - É o animal mais alto do mundo"
        break;

    case 5:
        mensagem = "Coelho - amplo campo de visão e boa audição"
        break;
 }
 console.log(filme);
 console.log(mensagem);