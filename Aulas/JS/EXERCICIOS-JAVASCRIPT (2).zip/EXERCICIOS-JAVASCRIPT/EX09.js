let catetop = 10;
let catetoadjacente = 20;
let co = (Math.pow(10,2));
let ca = (Math.pow(20,2));