let numero = [2,3,4];
let numero2 = [2,3,4];
let numeronovo = []

let soma= 0;
let soma2 = 0;

for(let i = 0; i< numero.length; i++){
    soma+=numero[i]
}
for(let j = 0; j< numero2.length; j++){

}
numeronovo = [soma +soma2]

console.log(numeronovo);