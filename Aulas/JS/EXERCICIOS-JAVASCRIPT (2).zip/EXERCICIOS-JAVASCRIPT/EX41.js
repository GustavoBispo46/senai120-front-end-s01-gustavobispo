let mes = 8; 
let mensagem;

switch (mes){
    case 1:
        mensagem = "o mês escolhido é Janeiro"
    break;
    case 2:
        mensagem = "o mês escolhido é Fevereiro"
    break;
    case 3:
        mensagem = "o mês escolhido é Março"
    break;
    case 4:
        mensagem = "o mês escolhido é Abril"
    break;
    case 5:
        mensagem = "o mês escolhido é Maio"
    break;
    case 6:
        mensagem = "o mês escolhido é Junho"
    break;
    case 7:
        mensagem = "o mês escolhido é Julho"
    break;
    case 8:
        mensagem = "o mês escolhido é Agosto"
    break;
    case 9:
        mensagem = "o mês escolhido é Setembro"
    break;
    case 10:
        mensagem = "o mês escolhido é Outubro"
    break;
    case 11:
        mensagem = "o mês escolhido é Novembro"
    break;
    case 12:
        mensagem = "o mês escolhido é Dezembro"
    break;
    default:
        mensagem = "Dia inválido"
}
console.log(mes);
console.log(mensagem);