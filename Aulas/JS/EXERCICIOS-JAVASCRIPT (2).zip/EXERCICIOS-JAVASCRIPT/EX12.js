let distancia = 100; 
let tempo = 2; 
let velocidadeMedia = distancia / tempo;

console.log(velocidadeMedia); 