let massa = 20;
let volume = 10;
let densidade = massa/volume
console.log(densidade);