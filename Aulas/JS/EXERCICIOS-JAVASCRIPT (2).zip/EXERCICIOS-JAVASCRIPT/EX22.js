let n1 = 6;
if (n1 % 2 ==0){
    console.log("O seu número é par");
}
else if (n1%2<=0)
console.log("O seu número é impar");