let b = 4
let l = 2
let h = 1
let multi = b*l*h
console.log(multi);