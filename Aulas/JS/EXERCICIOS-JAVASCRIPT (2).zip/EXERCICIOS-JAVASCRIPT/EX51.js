let numero1 = 1;

while (numero1<10){ 
console.log(numero1);
numero1 ++
}