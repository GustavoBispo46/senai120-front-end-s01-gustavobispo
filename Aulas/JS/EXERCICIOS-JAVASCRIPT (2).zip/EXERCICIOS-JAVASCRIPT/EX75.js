let n = 1;

for(let i = 0; i<=10; i++){
    console.log(`${n}x${i}=${n*i}`);
}