
let numeros= Number(prompt("digite 5 números, OBS o ultimo devera ser negativo!"))
if(numeros<=[3,2,1,0,-1]){
alert(digite novamente)
}
