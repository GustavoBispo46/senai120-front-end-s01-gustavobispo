let preco = 400
let desconto = 20/100;
let valordesconto = preco * desconto
console.log(valordesconto);
let vslordesconto = preco - valordesconto;
console.log(valordesconto);