let num = 4;

if (num % 3 === 0 && num % 5 === 0) {
  console.log("O número é múltiplo de 3 e 5");
} else {
  console.log("O número não é múltiplo de 3 e 5");
}