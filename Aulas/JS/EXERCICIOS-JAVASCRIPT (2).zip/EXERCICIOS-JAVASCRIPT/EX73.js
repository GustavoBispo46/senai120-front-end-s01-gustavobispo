for ( let i = 0; i<= 50; i +=2){
    console.log(i);
}