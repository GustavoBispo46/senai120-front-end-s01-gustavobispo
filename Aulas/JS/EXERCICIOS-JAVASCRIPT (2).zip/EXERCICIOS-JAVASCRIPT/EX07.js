let lado = 5;
let p = 3;
let perimetro = lado*p
console.log(perimetro);