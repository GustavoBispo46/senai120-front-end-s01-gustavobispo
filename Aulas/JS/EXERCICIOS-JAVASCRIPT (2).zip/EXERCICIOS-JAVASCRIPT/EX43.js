let produto = 3; 
let mensagem;

switch(produto){
case 1:
        mensagem = "Camiseta - 29,99"
    break;
case 2: 
    mensagem = "Bermuda - 49,99" 
    break;   
case 3: 
    mensagem = "Calça Jeans - 75,99" 
    break;   
case 4: 
    mensagem = "Boné - 35,99" 
    break;   
case 5: 
    mensagem = "Par de Meias - 12,99"
    break;    
}
console.log(produto);
console.log(mensagem);