let valor = 700;
let taxa = 0.45;
let tempo = 15;
let valorfuturo = valor * Math.pow(valor + taxa, tempo)
console.log(valorfuturo);