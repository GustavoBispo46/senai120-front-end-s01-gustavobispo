let n1 = prompt ("Digite um número");
while (n1){
    if (n1%2 ==0)
    alert(n1 = "o seu número é par")
    else(
        alert(n1="O seu número é impar")
    )
    n1 ++
}