let diadasemana = 3;
let mensagem;

switch (diadasemana) {
    case 1:
        mensagem = "Segunda" + " Monday"
        break;

    case 2:
        mensagem = "Terça" + " Tuesday"
        break;

    case 3:
        mensagem = "Quarta" + " Wednesday"
        break;

    case 4:
        mensagem = "Quinta" + " Thursday"
        break;

    case 5:
        mensagem = "Sexta" + " Friday"
        break;
    case 6:
        mensagem = "Sábado" + " Saturday"
        break;
    case 7:
        mensagem = "Domingo" + " Sunday"
        break;
 }
 console.log(diadasemana);
 console.log(mensagem);