let n = 15;
let triplo = 3;
let mult = n * triplo
console.log(mult);