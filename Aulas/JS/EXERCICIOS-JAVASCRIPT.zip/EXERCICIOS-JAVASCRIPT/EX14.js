let raio = (Math.pow(12,3))
let pi = 3.14;
let n1 = 4;
let n2 = 3;

let volesfera = n1 * p1 * raio/n2;
console.log(volesfera);