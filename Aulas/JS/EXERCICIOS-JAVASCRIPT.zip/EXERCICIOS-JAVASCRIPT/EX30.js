let salario = 2000;
let aumento = 20/100;

let valorAumento = salario * aumento
console.log(valorAumento);
let valorcomAumento = salario + valorAumento;
console.log(valorcomAumento);