let n1 = 4;
let n2 = 9;
let soma = (n1+n2)
if (soma>11)
{console.log("A soma dos dois é maior que 11!");}
else if(soma<=11){
    console.log("A soma dos dois não é maior que 11!");
}
