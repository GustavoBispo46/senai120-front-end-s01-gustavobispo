let numero1 = 10;

while (numero1>=0){ 
console.log(numero1);
numero1 --
}