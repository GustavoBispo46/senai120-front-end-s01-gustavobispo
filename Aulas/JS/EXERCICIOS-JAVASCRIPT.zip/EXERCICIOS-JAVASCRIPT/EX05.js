let q1 = 2
let q2 = 2
let area = q1*q2
console.log(area);