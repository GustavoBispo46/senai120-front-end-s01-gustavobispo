let operacao = "multiplicação";
let calculo;
let n1 = 10;
let n2 = 20;

operacao = operacao.toLocaleLowerCase().trim()

switch(operacao) {
    case "soma":
        calculo = n1 + n2
        console.log(`${n1}+${n2}=${calculo}`);
        break;

        case "subtracao";
        case "subtração";
}