let idade = 16;
let altura = 1.75;

if (idade >= 12 && altura >= 1.50) {
  console.log("Você pode andar no brinquedo!");
} else {
  console.log("você não pode andar neste brinquedo.");}