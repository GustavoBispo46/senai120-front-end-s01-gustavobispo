let senha = 123456789

if (senha >= 8) {
  console.log("Senha válida.");
} else {
  console.log("Senha inválida.");
}