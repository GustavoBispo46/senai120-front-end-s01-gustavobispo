let n = 12;
let d = 2;
let div = n / d
console.log(div);