let num = 8;

if (num % 2 === 0) {
  console.log("O número é divisível por 2");
} else if (num % 3 === 0) {
  console.log("O número é divisível por 3");
} else {
  console.log("O número não é divisível por 2 nem por 3");
}