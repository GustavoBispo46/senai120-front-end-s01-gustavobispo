let raio = 1.25;
let area = 0;

area = Math.PI*raio*raio;
console.log(area + area);