let n1 = 5;
let n2 = 0;

while (n2 <= 50) {
    console.log(`${n1} x ${n2} = ${n1*n2}`);
    n2++
}