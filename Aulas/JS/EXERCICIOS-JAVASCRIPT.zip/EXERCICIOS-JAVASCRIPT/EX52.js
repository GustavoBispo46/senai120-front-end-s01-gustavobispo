let numero1 = 2;

while(numero1 <=10){
    if(numero1 % 2 ==0)

        console.log(numero1);
        numero1 ++
    }
    
