let n = -6;
if (n === 0) {
    console.log("O número digitado é zero.");
  }
  else if (n > 0) {
    console.log("O número digitado é positivo.");
  }
  else {
    console.log("O número digitado é negativo.");
  }
