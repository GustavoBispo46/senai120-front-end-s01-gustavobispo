let idade = 18
if (idade < 8) {
    console.log("Categoria Infantil A");
  } else if (idade < 11) {
    console.log("Categoria Infantil B");
  } else if (idade < 14) {
    console.log("Categoria Juvenil A");
  } else if (idade < 18) {
    console.log("Categoria Juvenil B");
  } else {
    console.log("Categoria Adulto");
  }