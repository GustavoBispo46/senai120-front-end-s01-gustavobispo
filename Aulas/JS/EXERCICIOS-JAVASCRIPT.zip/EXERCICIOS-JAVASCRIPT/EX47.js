let fruta = 3;
let mensagem;

switch(fruta){
    case 1:
    mensagem = "Morango" + "Vermelho"
    break;
    case 2:
        mensagem ="Abacate"+"Verde"
        break;   
    case 3:
        mensagem ="Limão"+"Verde"
        break;   
    case 4:
        mensagem ="Pera"+"Verde"
        break;   
    case 5:
        mensagem ="Uva"+"Roxa"
        break;   
}
