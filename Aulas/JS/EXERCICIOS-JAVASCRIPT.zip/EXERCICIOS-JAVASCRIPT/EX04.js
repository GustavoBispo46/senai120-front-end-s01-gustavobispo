let n = 50;
let div = 0.25;
let pct = n*div
console.log(pct);
